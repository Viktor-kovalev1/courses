import os
import openmc
import numpy as np
import math

from chanel_3d import get_plane, set_chanel_3d
from coolant_cell_construction import coolant_cell_construction
from materials import coolant




def coolant_3d(tvs_ind = 5000,coolant=coolant, boundary="transmission/reflective"):
    # z boundaries - определяем условия отражения для высотных слоев
    # следует учесть, что источник устанавливается в точку (0,0) и,
    # поэтому слои должны охватывать источник сверху и снизу
    z0 = 0
    ztype1 = z0 + 33
    ztype2 = z0 + 66
    ztype3 = z0 + 99
    ztype4 = z0 + 132
    ztype5 = z0 + 165
    
    #print ("Топливаня сборка ", z_us)    

    core_down = openmc.ZPlane( z0= z0 , boundary_type="vacuum")
    core_up =   openmc.ZPlane( z0= ztype5 , boundary_type="vacuum")



    #  создадим послойно ячейки с разными материалами
    # !!! приходиться создать дополнительные ячейки и Universe, чтобы можно было получить
    # !!! не только срдение значения по всей ТВС, но и средние значения по слоям

    # вселенным, по которым будут усреднятся сечения зададим сами уникальные идентификаторы (id)
    cell_name = "coolant cell"
    coolant_cell =  coolant_cell_construction(cell_name=cell_name, coolant=coolant, zup=core_up, zdn=core_down, boundary=boundary)
    coolant_unverse = openmc.Universe(universe_id =tvs_ind, name=f'universe_{tvs_ind}_{cell_name}')
    coolant_unverse.add_cell(coolant_cell)

 
    return coolant_unverse


if __name__ == '__main__':
    os.environ["OPENMC_CROSS_SECTIONS"] = "/home/viktor/openmc/endfb-viii.0-hdf5/cross_sections.xml"
    #os.environ["OPENMC_CROSS_SECTIONS"] = "/home/openmc/projects/xsections/endfb80_hdf5/cross_sections.xml"


    mats = openmc.Materials( [coolant])
    mats.export_to_xml()


    coolant_unverse = coolant_3d( coolant = coolant, boundary="reflective")

    # вводим геометрию корневого объекта
    geom = openmc.Geometry(coolant_unverse)
    geom.export_to_xml()


    z0 = 0
    ztype1 = z0 + 33
    ztype2 = z0 + 66
    ztype3 = z0 + 99
    ztype4 = z0 + 132
    ztype5 = z0 + 165


    # печать картинки
    p = openmc.Plot()
    # возможность задания срезов для отображения
    p.origin=(0,0,z0+1)
    p.filename = 'coolant_xy'
    p.basis = "xy"
    p.width = (26, 26)
    p.pixels = (1000, 1000)
    p.color_by = 'material'
    p.colors = {coolant: 'blue' }

    plots = openmc.Plots([p])
    plots.export_to_xml()
    openmc.plot_geometry()
#------------
    # возможность задания срезов для отображения
    p.origin=(0,0,165/2)
    p.filename = 'coolant_yz'
    p.basis = "xz"
    p.width = (26, 600)
    p.pixels = (1000, 1000)
    p.color_by = 'material'
    p.colors = {coolant: 'blue'}


    plots = openmc.Plots([p])
    plots.export_to_xml()
    openmc.plot_geometry()
#-------------------


    #Computing settings
    batches = 40
    inactive = 10
    particles = 1000

    set = openmc.Settings()
    set.batches = batches
    set.inactive = inactive
    set.particles = particles
    set.output = {'tallies': True}
    # установка точечного источника (могут быть разные)
    sourse_point = openmc.stats.Point(xyz=(0,0, ztype3 +1))
    set.source =openmc.Source(space = sourse_point)


    set.export_to_xml()


  
    openmc.run(threads=6)#, geometry_debug=True)
    
