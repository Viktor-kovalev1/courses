import csv
file_path = "results_kr.txt"
filtered_lines = []

with open(file_path, 'r') as file:
    for line in file:
        if "x-max out" in line and '0.00e+00' not in line:
            a=line.split()
            filtered_lines.append((float(a[10]),float(a[11]),int(a[2]),int(a[3])))
arr=[0 for i in range(16)]
arrstdev= [0 for i in range(16)]
for elem in filtered_lines:
    for i in range(1,17):
        if elem[3]==i:
            arr[i-1]+= elem[0]*300000*9.44*10**12*16/165
            arrstdev[i-1]+= elem[1]*300000*9.44*10**12*16/165
print(arrstdev)
print(max(arr)/10**14)
# array=[]
# for i in range(33):
#     arr=[]
#     j=0
#     while j<21:
#         arr.append(float(filtered_lines[j+i*21]))
#         j += 1
#     array.append(arr)
# print(array)
# print(len(array))
# with open('fuck_kv.csv', 'w') as f:
#     yoba=csv.writer(f)
#     for elem in array:

        # yoba.writerow(elem)
# for elem in filtered_lines:
#
#     print(float(elem))
#print(len(filtered_lines))