import os
import openmc
import numpy as np
import math

from chanel_3d import get_plane, set_chanel_3d
import sys
sys.path.append('../')
from materials import coolant



def coolant_cell_construction(cell_name, coolant, zup=None, zdn=None, boundary="transmission/reflective"):
    # устанавливаем чехол

    # создаем внешний слой теплоносителя
    H_fuel_assembly = 16.2471
    bord_outer = get_plane(H= H_fuel_assembly, boundary=boundary)

    # создаем ТВС (без чехла), чтобы для нее можно было задать внешние границы
    root_cell = openmc.Cell(name='coolant_cell {}'.format(cell_name), fill=coolant)
    root_cell.region = -bord_outer[1] & -bord_outer[2] & -bord_outer[3] & -bord_outer[4] & -bord_outer[5] & -bord_outer[6] & -zup & +zdn

    return root_cell



