import os
import openmc
import numpy as np
import math

from chanel_3d import get_plane, set_chanel_3d
import sys
sys.path.append('../')
from fuel_assembly import assembly_layer_construct
from control_rods import assembly_construct
from materials import fuel_type1inner
from materials import fuel_type2inner
from materials import fuel_type3inner
from materials import fuel_type4inner
from materials import fuel_type5inner

from materials import fuel_type1outer
from materials import fuel_type2outer
from materials import fuel_type3outer
from materials import fuel_type4outer
from materials import fuel_type5outer


from materials import coolant, structure, clading, svp, protection, gilza




def fa_3d_rod(tvs_ind=1000, fuels_lst = [fuel_type1inner,fuel_type2inner,fuel_type3inner,fuel_type4inner,fuel_type5inner],absorber= svp,absorber1=protection, gilza=gilza, absorber_insert=True, boundary="transmission/reflective"):
    # z boundaries - определяем условия отражения для высотных слоев
    # следует учесть, что источник устанавливается в точку (0,0) и,
    # поэтому слои должны охватывать источник сверху и снизу
    z0 = 0
    h_stergen=25
    ztype1 = z0 + 33
    ztype2 = z0 + 66
    ztype3 = z0 + 99
    ztype4 = z0 + 132
    ztype5 = z0 + 165
    ztypex=165-h_stergen
    
    #print ("Топливаня сборка ", z_us)    

    core_down = openmc.ZPlane(z0= z0 , boundary_type="vacuum")
    z_ft1 = openmc.ZPlane(z0= ztype1 , boundary_type="transmission")
    z_ft2 = openmc.ZPlane(z0= ztype2 , boundary_type="transmission")
    z_ft3 = openmc.ZPlane(z0= ztype3 , boundary_type="transmission")
    z_ft4 = openmc.ZPlane(z0= ztype4 , boundary_type="transmission")
    z_ft5 = openmc.ZPlane(z0= ztype5 , boundary_type="vacuum")
    z_ftx=openmc.ZPlane(z0= ztypex , boundary_type="transmission")
    






    #  создадим послойно ячейки с разными материалами
    # !!! приходиться создать дополнительные ячейки и Universe, чтобы можно было получить
    # !!! не только срдение значения по всей ТВС, но и средние значения по слоям

    # вселенным, по которым будут усреднятся сечения зададим сами уникальные идентификаторы (id)
    cell_name = "fuel assembly inner fuel 1"
    root_cell_3 = assembly_construct( cell_name=cell_name,fuel=fuels_lst[0], clading=clading, coolant=coolant, zup=z_ft1, zdn=core_down, zx=z_ftx, boundary=boundary)
    universe3 = openmc.Universe(name=f'universe_{tvs_ind}_{cell_name}')
    universe3.add_cell(root_cell_3)
    view_cell_3 = openmc.Cell( name="view_fuel_1", fill=universe3)
    view_cell_3.region = root_cell_3.region


    cell_name = "fuel assembly inner fuel 2"
    root_cell_4 = assembly_construct(cell_name=cell_name,fuel=fuels_lst[1], clading=clading, coolant=coolant , zup=z_ft2, zdn=z_ft1, zx=z_ftx, boundary=boundary)
    universe4 = openmc.Universe(name=f'universe_{tvs_ind+200}_{cell_name}')
    universe4.add_cell(root_cell_4)
    view_cell_4 = openmc.Cell( name="view_fuel_2", fill=universe4)
    view_cell_4.region = root_cell_4.region


    cell_name = "fuel assembly inner fuel 3"
    root_cell_5 = assembly_construct( cell_name=cell_name,fuel=fuels_lst[2], clading=clading, coolant=coolant , zup=z_ft3, zdn=z_ft2, zx=z_ftx, boundary=boundary)
    universe5 = openmc.Universe(name=f'universe_{tvs_ind+400}_{cell_name}')
    universe5.add_cell(root_cell_5)
    view_cell_5 = openmc.Cell( name="view_fuel_3", fill=universe5)
    view_cell_5.region = root_cell_5.region


    cell_name = "fuel assembly inner fuel 4"
    root_cell_6 = assembly_construct( cell_name=cell_name,fuel=fuels_lst[3], clading=clading, coolant=coolant , zup=z_ft4, zdn=z_ft3, zx=z_ftx, boundary=boundary)
    universe6 = openmc.Universe(name=f'universe_{tvs_ind+600}_{cell_name}')
    universe6.add_cell(root_cell_6)
    view_cell_6 = openmc.Cell(name="view_fuel_4", fill=universe6)
    view_cell_6.region = root_cell_6.region


    cell_name = "fuel assembly inner fuel 5"
    root_cell_7 = assembly_construct( cell_name=cell_name,fuel=fuels_lst[4], clading=clading, coolant=coolant , zup=z_ft5, zdn=z_ft4, zx=z_ftx, boundary=boundary)
    universe7 = openmc.Universe(name=f'universe_{tvs_ind+800}_{cell_name}')
    universe7.add_cell(root_cell_7)
    view_cell_7 = openmc.Cell( name="view_fuel_5", fill=universe7)
    view_cell_7.region = root_cell_7.region
    
    
    
    

    





    # здадим объединенную Universe, которую и будем рассчитывать
    fa_inner_universe_return = openmc.Universe(universe_id =tvs_ind, name='fa_inner_universe')

    fa_inner_universe_return.add_cell(view_cell_3)
    fa_inner_universe_return.add_cell(view_cell_4)
    fa_inner_universe_return.add_cell(view_cell_5)
    fa_inner_universe_return.add_cell(view_cell_6)
    fa_inner_universe_return.add_cell(view_cell_7)


    
    return fa_inner_universe_return


if __name__ == '__main__':
    os.environ["OPENMC_CROSS_SECTIONS"] = "/home/adminsrv/projects/sections/endfb-viii.0-hdf5/cross_sections.xml"
    



    mats = openmc.Materials((fuel_type1inner, fuel_type2inner,  fuel_type3inner,  fuel_type4inner,  fuel_type5inner,
                             fuel_type1outer, fuel_type2outer,  fuel_type3outer,  fuel_type4outer,  fuel_type5outer,
                             clading, coolant, structure,svp,protection,gilza))
    mats.export_to_xml()

    fuels_inner_lst = [fuel_type1inner,fuel_type2inner,fuel_type3inner,fuel_type4inner,fuel_type5inner]
    fuels_outer_lst = [fuel_type1outer,fuel_type2outer,fuel_type3outer,fuel_type4outer,fuel_type5outer]



    fa_inner_universe = fa_3d_rod(tvs_ind = 1000, fuels_lst=fuels_inner_lst, absorber=svp, absorber1=protection, gilza=gilza,  absorber_insert= True, boundary="reflective")

    # вводим геометрию корневого объекта
    geom = openmc.Geometry(fa_inner_universe)
    geom.export_to_xml()


    z0 = 0
    ztype1 = z0 + 33
    ztype2 = z0 + 66
    ztype3 = z0 + 99
    ztype4 = z0 + 132
    ztype5 = z0 + 165


    # печать картинки
    p = openmc.Plot()
    # возможность задания срезов для отображения
    p.origin=(0,0,z0+1)
    p.filename = f'rod_assembly_xy'
    p.basis = "xy"
    p.width = (26, 26)
    p.pixels = (1000, 1000)
    p.color_by = 'material'
    p.colors = {fuel_type1inner: 'red',
                fuel_type2inner: 'orange',
                fuel_type3inner: 'magenta',
                fuel_type4inner: 'coral',
                fuel_type5inner: 'pink',
                coolant: 'blue',
                clading:'gray',
                structure:'gray',
                svp : 'green',
                protection: 'black',
                gilza:'white'
               }

    plots = openmc.Plots([p])
    plots.export_to_xml()
    openmc.plot_geometry()
#------------
    # возможность задания срезов для отображения
    p.origin=(0,0,165/2)
    p.filename = f'rod_assembly_yz'
    p.basis = "xz"
    p.width = (26, 600)
    p.pixels = (1000, 1000)
    p.color_by = 'material'
    p.colors = {fuel_type1inner: 'red',
                fuel_type2inner: 'orange',
                fuel_type3inner: 'magenta',
                fuel_type4inner: 'coral',
                fuel_type5inner: 'pink',
                coolant: 'blue',
                clading:'gray',
                structure:'gray',
                svp : 'green',
                protection: 'black',
                gilza: 'white'
               }


    plots = openmc.Plots([p])
    plots.export_to_xml()
    openmc.plot_geometry()
#-------------------


    #Computing settings
    batches = 40
    inactive = 10
    particles = 1000

    set = openmc.Settings()
    set.batches = batches
    set.inactive = inactive
    set.particles = particles
    set.output = {'tallies': True}
    # установка точечного источника (могут быть разные)
    sourse_point = openmc.stats.Point(xyz=(0,0, ztype3 +1))
    set.source =openmc.Source(space = sourse_point)
    set.temperature = {"method": "interpolation"}


    set.export_to_xml()




    openmc.run()
    
