import csv
file_path = "tallies.out"
filtered_lines = []

with open(file_path, 'r') as file:
    for line in file:
        if "Fission Rate" in line and '0.00000' not in line:
            a=line.replace(' ','').split('=')
            x=a[1].split('+/-')
            filtered_lines.append(float(x[1])/float(x[0]))
cov=sum(filtered_lines)/len(filtered_lines)
print(cov)
# array=[]
# for i in range(33):
#     arr=[]
#     j=0
#     while j<21:
#         arr.append(float(filtered_lines[j+i*21]))
#         j += 1
#     array.append(arr)
# print(array)
# print(len(array))
# with open('fuck_kv.csv', 'w') as f:
#     yoba=csv.writer(f)
#     for elem in array:
#
#         yoba.writerow(elem)
# # for elem in filtered_lines:
# #
# #     print(float(elem))
# #print(len(filtered_lines))