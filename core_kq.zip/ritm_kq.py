import os
import csv
import openmc
import sys

sys.path.append('../')
from fa_calculation_true import fa_3d
import numpy as np
import math
from chanel_3d import get_plane, set_chanel_3d


from materials import fuel_type1inner,  fuel_type1outer
from materials import fuel_type2inner,  fuel_type2outer
from materials import fuel_type3inner,  fuel_type3outer
from materials import fuel_type4inner,  fuel_type4outer
from materials import fuel_type5inner,  fuel_type5outer
from materials import coolant,  clading,svp,protection,gilza,svpmin

from control_rods_up_calculation import fa_3d_rod

from coolant import coolant_3d


os.environ["OPENMC_CROSS_SECTIONS"] = "/home/adminsrv/projects/sections/endfb-viii.0-hdf5/cross_sections.xml"

mats = openmc.Materials((fuel_type1inner, 
                         fuel_type2inner,
                         fuel_type3inner,
                         fuel_type4inner,
                         fuel_type5inner,
                         fuel_type1outer,
                         fuel_type2outer,
                         fuel_type3outer,
                         fuel_type4outer,
                         fuel_type5outer,
                         clading, coolant,svp,protection,gilza,svpmin))
                         
mats.export_to_xml()





#---------------------------------------------
# размер под ключ для ТВС
# создаем окружающие ТВС
outer_coolant_cell = openmc.Cell(fill=coolant)
outer_universe = openmc.Universe(cells=(outer_coolant_cell,))
HH=9.85
lattice = openmc.HexLattice(name='core_lattice')
lattice.center = (0., 0.)
lattice.pitch = (HH,)
lattice.outer = outer_universe






fuels_inner_lst  = [fuel_type1inner,fuel_type2inner,fuel_type3inner,fuel_type4inner,fuel_type5inner]
fuels_outer_lst  = [fuel_type1outer,fuel_type2outer,fuel_type3outer,fuel_type4outer,fuel_type5outer]
# создаем реактор
def lat(ind=1000, fuel_type=fuels_inner_lst ):
    return fa_3d(tvs_ind=ind, fuels_lst=fuel_type, boundary="transmission")
ring_1=[lat(1000,fuels_outer_lst)]
ring_2=[lat(2000,fuels_outer_lst)]*6
ring_3=[lat(3000,fuels_outer_lst)]*12
ring_4=[lat(4000,fuels_outer_lst)]*18
ring_5=([lat(ind=5000,fuel_type=fuels_outer_lst)]*2+[fa_3d_rod(tvs_ind=105000, boundary="transmission")]+[lat(ind=5000,fuel_type=fuels_outer_lst)])*6
ring_6=([lat(ind=6000,fuel_type=fuels_outer_lst)])*30
ring_7=([lat(ind=7000,fuel_type=fuels_outer_lst)])*36
ring_8=([fa_3d_rod(tvs_ind=108000, boundary="transmission")]+[lat(ind=8000,fuel_type=fuels_outer_lst)]*6)*6
ring_9=([lat(ind=9000,fuel_type=fuels_inner_lst)])*48
ring_10=([lat(ind=10000,fuel_type=fuels_inner_lst)]*4+[fa_3d_rod(tvs_ind=110000, boundary="transmission")]+[lat(ind=10000,fuel_type=fuels_inner_lst)]*4)*6
ring_11=[lat(ind=11000,fuel_type=fuels_inner_lst)]*60
ring_12=([coolant_3d( tvs_ind=1012000 ,coolant = coolant, boundary="transmission")]*3+[lat(12000,fuels_inner_lst)]*6+[coolant_3d( tvs_ind=1012000 ,coolant = coolant, boundary="transmission")]*2)*6




#print(len(ring_12))
lattice.universes = [ring_12,ring_11, ring_10, ring_9, ring_8, ring_7, ring_6, ring_5, ring_4, ring_3, ring_2, ring_1]
#lattice.universes = [ring_5,ring_4,ring_3, ring_2, ring_1]
lattice.orientation = 'x'

print(lattice)







z0 = 0               # cm core down position
#z1 = 35.76           # cm Lower structure
#z2 = z1 + 125.16     # cm Lower reflector
z3 = z0 + 165     # cm Radial reflector
#z_us = z3 + 112.39   # cm Upper structure
core_down = openmc.ZPlane(z0= z0+2 , boundary_type="vacuum")
core_up = openmc.ZPlane(z0= z3-2 , boundary_type="vacuum")




# размер под ключ для кластера
Hcluster=HH*12
cluster_border = get_plane(H= Hcluster, orientation="y", boundary="vacuum")

cluster_region = -cluster_border[1] & -cluster_border[2] & -cluster_border[3] & -cluster_border[4] & -cluster_border[5] & -cluster_border[6] & -core_up & +core_down

main_cell = openmc.Cell(fill=lattice, region= cluster_region)
geom = openmc.Geometry([main_cell])
geom.export_to_xml()







z_core_pos = 165/2

# печать картинки
p = openmc.Plot()
p.origin=(0,0,z_core_pos)
p.basis = "xz"
p.filename = f'core_z'
p.width = (HH*33, HH*33)
p.pixels = (5000, 5000)
p.color_by = 'material'

p.colors = {fuel_type1inner: 'red',
            fuel_type2inner: 'orange',
            fuel_type3inner: 'magenta',
            fuel_type4inner: 'orange',
            fuel_type5inner: 'red',
            coolant: 'blue',
            clading:'gray',
            svp:'green',
            svpmin: 'green',
            protection : 'black',
            gilza :'yellow'           
            }            

plots = openmc.Plots([p])
plots.export_to_xml()
openmc.plot_geometry()

#------------------
# печать картинки
p = openmc.Plot()
p.origin=(0,0,100)
p.basis = "xy"
p.filename = f'core_xy'
p.width = (HH*33, HH*33)
p.pixels = (5000, 5000)
p.color_by = 'material'
p.colors = {fuel_type1inner: 'red',
            fuel_type2inner: 'orange',
            fuel_type3inner: 'magenta',
            fuel_type4inner: 'orange',
            fuel_type5inner: 'red',
            coolant: 'blue',
            clading:'gray',
            svp :'green',
            svpmin: 'green',
            protection : 'black',
            gilza :'yellow'  
            }            



plots = openmc.Plots([p])
plots.export_to_xml()
openmc.plot_geometry()
#--------------




#Computing settings
batches = 100
inactive = 20
particles = 300



settings = openmc.Settings()
settings.batches = batches
settings.inactive = inactive
settings.particles = particles
settings.output = {'tallies': True}
settings.temperature = {'method': 'interpolation'}
box_size = HH*2
uniform_dist = openmc.stats.Box([-box_size,-box_size,100],[box_size,box_size,120],only_fissionable=True)
settings.source = openmc.source.Source(space=uniform_dist)
settings.export_to_xml()





#========
# Instantiate an empty Tallies object
tallies_file = openmc.Tallies()
# Instantiate energy filter for multi-group cross-section Tallies
energy_filter = openmc.EnergyFilter([0., 20.0e6])
# Instantiate flux Tally in moderator and fuel
tally = openmc.Tally(name='flux_result')

# создаем сетчатый цилиндрический фильтр, по которому будем считать kv
mesh = openmc.CylindricalMesh(r_grid=[5*i for i in range(25)],z_grid=[5*i for i in range(34)])

universe_filter=openmc.MeshFilter(mesh)
tally.filters = [ universe_filter ]
tally.filters.append(energy_filter)
# выбираем функционал
tally.scores = ['fission']
tallies_file.append(tally)
tallies_file.export_to_xml()
#========    



openmc.run()


# хотим посмотреть поток в одной ТВС
sp = openmc.StatePoint('statepoint.100.h5')
energovidilenie = sp.get_tally(name='flux_result')
#Get a pandas dataframe for the mesh tally data
df = energovidilenie.get_pandas_dataframe()
# сохраняем изначальные результаты
with open("results_kr.txt", 'w') as f:
    f.write(df.to_string())




# получаем сами значения
values=energovidilenie.get_values()

# разглаживаем массив, убирая лишние скобки
values2=np.array(values.flatten())
#создаем текстовый файл с данными
unzero_values=np.array([elem for elem in values2 if elem!=0])
with open('chetkiy_fayl_kr.txt','w') as f:
    lines={}
    with open('results_kr.txt','r') as fayl:
        for line in fayl.readlines():
            if '[eV]' not in line:
                line1=line.split()
                if float(line1[6])!=0:
                    lines.update({int(float(line1[1])/1000) : float(line1[6])})

    for key in lines.keys():
        f.write(str(key)+' , '+ str(lines[key])+'    \n')

# получаем среднее значение энерговыделения в кассете
meanval=sum(unzero_values)/len(unzero_values)

# получаем коэф неравномерности
kr=unzero_values/meanval

# сохраняем в файл
with open("kr.txt", 'w') as f:
    for el in kr:
        stra = f"{el:.3f}\n"
        f.write(stra)
