import openmc
import numpy as np
import openmc.deplete
import openmc.deplete
import matplotlib.pyplot as plt
import os
# temperatures for MET-1000
fuel_temperature = 363 + 273.15
coolant_temperature = 335 + 273.15
structure_temperature = 326 + 273.15
r_pin=0.69/2
r_svp=0.69/2 # cm

#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type1outer  ALL FUEL ASSEMBLY
# Топливо в центре 19%
fuel_type1inner = openmc.Material( name=f'fuel_type1inner')
fuel_type1inner.add_nuclide('U235',4.6599E-03)
fuel_type1inner.add_nuclide('U238',1.9866E-02)
fuel_type1inner.add_nuclide('O16',4.9052E-02)

#fuel_type1inner.volume=   72*  np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type1inner.volume=np.pi * r_pin ** 2*33
fuel_type1inner.depletable = True
fuel_type1inner.temperature=fuel_temperature

#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core bounday distance 68.66 cm to fuel_type1outer  ALL FUEL ASSEMBLY
# Топливо на переферии 18%
fuel_type2inner = openmc.Material( name= 'fuel_type2inner')
#fuel_type2inner.add_nuclide('U234',1.1759E-06)
fuel_type2inner.add_nuclide('U235',4.4147E-03)
#fuel_type2inner.add_nuclide('U236',2.0226E-06)
fuel_type2inner.add_nuclide('U238',2.0111E-02)
fuel_type2inner.add_nuclide('O16',4.9052E-02)


#fuel_type2inner.volume=72*np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type2inner.volume=np.pi * r_pin ** 2*33
fuel_type2inner.depletable = True
fuel_type2inner.temperature=fuel_temperature

#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 51.49 cm to fuel_type1outer  ALL FUEL ASSEMBLY
#3 Тип топлива 15%
fuel_type3inner = openmc.Material( name='fuel_type3inner')
#fuel_type3inner.add_nuclide('U234',1.0727E-06)
fuel_type3inner.add_nuclide('U235',3.6789E-03)
#fuel_type3inner.add_nuclide('U236',2.5536E-06)
fuel_type3inner.add_nuclide('U238',2.0847E-02)
fuel_type3inner.add_nuclide('O16',4.9052E-02)
#fuel_type3inner.add_nuclide('Np237', 4.6782E-05)

#fuel_type3inner.volume=72*np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type3inner.volume=np.pi * r_pin ** 2*33
fuel_type3inner.depletable = True
fuel_type3inner.temperature=fuel_temperature

#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type4inner  ALL FUEL ASSEMBLY 18%
fuel_type4inner = openmc.Material( name='fuel_type4inner')
#fuel_type4inner.add_nuclide('U234',1.1028E-06)
fuel_type4inner.add_nuclide('U235',4.4147E-03)
#fuel_type4inner.add_nuclide('U236',2.3779E-06)
fuel_type4inner.add_nuclide('U238',2.0111E-02)
fuel_type4inner.add_nuclide('O16',4.9052E-02)
#fuel_type4inner.add_nuclide('Np237', 4.7603E-05)



#fuel_type4inner.volume=72*np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type4inner.volume=np.pi * r_pin ** 2*33
fuel_type4inner.depletable = True
fuel_type4inner.temperature=fuel_temperature

#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type5inner  ALL FUEL ASSEMBLY
fuel_type5inner = openmc.Material( name='fuel_type5inner')
#fuel_type5inner.add_nuclide('U234',1.1759E-06)
fuel_type5inner.add_nuclide('U235',4.6599E-03)
#fuel_type5inner.add_nuclide('U236',2.0226E-06)
fuel_type5inner.add_nuclide('U238',1.9866E-02)
fuel_type5inner.add_nuclide('O16',4.9052E-02)
#fuel_type5inner.add_nuclide('Np237', 4.8895E-05)


#
#fuel_type5inner.volume=72*np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type5inner.volume=np.pi * r_pin ** 2*33
fuel_type5inner.depletable = True
fuel_type5inner.temperature=fuel_temperature








#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type1outer  ALL FUEL ASSEMBLY
#  17%
fuel_type1outer = openmc.Material( name="fuel_type1outer")
#fuel_type1outer.add_nuclide('U234',1.6317E-06)
fuel_type1outer.add_nuclide('U235',4.515E-03)
#fuel_type1outer.add_nuclide('U236',1.7881E-06)
fuel_type1outer.add_nuclide('U238',2.2043E-02)



#fuel_type1outer.volume=   72*  np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type1outer.volume=np.pi * r_pin ** 2*33
fuel_type1outer.depletable = True
fuel_type1outer.temperature=fuel_temperature


#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type2outer  ALL FUEL ASSEMBLY 16%
fuel_type2outer = openmc.Material( name="fuel_type2outer")
#fuel_type2outer.add_nuclide('U234',1.5766E-06)
fuel_type2outer.add_nuclide('U235',4.2494E-03)
#fuel_type2outer.add_nuclide('U236',1.8534E-06)
fuel_type2outer.add_nuclide('U238',2.2309E-02)



#fuel_type2outer.volume=  72*   np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type2outer.volume=np.pi * r_pin ** 2*33
fuel_type2outer.depletable = True
fuel_type2outer.temperature=fuel_temperature


#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type3outer  ALL FUEL ASSEMBLY 14%
fuel_type3outer = openmc.Material( name="fuel_type3outer")
#fuel_type3outer.add_nuclide('U234',1.5638E-06)
fuel_type3outer.add_nuclide('U235',3.7182E-03)
#fuel_type3outer.add_nuclide('U236',1.8941E-06)
fuel_type3outer.add_nuclide('U238',2.2841E-02)



#fuel_type3outer.volume=   72*  np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type3outer.volume=np.pi * r_pin ** 2*33
fuel_type3outer.depletable = True
fuel_type3outer.temperature=fuel_temperature


#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type4outer  ALL FUEL ASSEMBLY 16%
fuel_type4outer = openmc.Material( name="fuel_type4outer")
#fuel_type4outer.add_nuclide('U234',1.5894E-06)
fuel_type4outer.add_nuclide('U235',4.2494E-03)
#fuel_type4outer.add_nuclide('U236',1.7528E-06)
fuel_type4outer.add_nuclide('U238',2.2309E-02)


#fuel_type4outer.volume=   72*  np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type4outer.volume=np.pi * r_pin ** 2*33
fuel_type4outer.depletable = True
fuel_type4outer.temperature=fuel_temperature


#--------------------------------------------------------------------------------
#Add nuclides concentration from inner core boundary distance 68.66 cm to fuel_type5outer  ALL FUEL ASSEMBLY 17%
fuel_type5outer = openmc.Material( name="fuel_type5outer")
#fuel_type5outer.add_nuclide('U234',1.6552E-06)
fuel_type5outer.add_nuclide('U235',4.515E-03)
#fuel_type5outer.add_nuclide('U236',1.4710E-06)
fuel_type5outer.add_nuclide('U238',2.2043E-02)



#fuel_type5outer.volume=  72*   np.pi * r_pin ** 2 # Задаем объем единичной высоты. Нужно для моделирования выгорания
fuel_type5outer.volume=np.pi * r_pin ** 2*33
fuel_type5outer.depletable = True
fuel_type5outer.temperature=fuel_temperature


#--------------------------------------------------------------------------------
#absorber natural
absorber_natural = openmc.Material( name="absorber_natural")
absorber_natural.add_nuclide('C12',1.943881E-02)
#absorber_natural.add_nuclide('C13',2.181927E-04)
#absorber_natural.add_nuclide('C0',1.9657E-02)
absorber_natural.add_nuclide('B10',1.5018E-02)
absorber_natural.add_nuclide('B11',6.3609E-02)
absorber_natural.temperature=fuel_temperature

#--------------------------------------------------------------------------------
#absorber enriched
absorber_enriched = openmc.Material( name="absorber_enriched")
#absorber_enriched.add_nuclide('C12',2.040298E-02)
#absorber_enriched.add_nuclide('C13',2.290152E-04)
#absorber_natural.add_nuclide('C0',2.0632E-02)
absorber_enriched.add_nuclide('B10',5.3642E-02)
absorber_enriched.add_nuclide('B11',2.8884E-02)

absorber_enriched.temperature=structure_temperature



#--------------------------------------------------------------------------------
# Na
# coolant = openmc.Material(name='Sodium')
# coolant.add_nuclide('Na23',2.227200E-02)
# coolant.temperature=coolant_temperature

# MOD1 pure water
coolant = openmc.Material(name='Pure Water')
coolant.add_nuclide('H1', 4.843E-02)
coolant.add_nuclide('O16', 2.422E-02)
coolant.add_nuclide('B10', 2.288E-06)
coolant.add_nuclide('B11', 9.24E-05)
coolant.add_s_alpha_beta('c_H_in_H2O')

#coolant.volume=  84*(28.9-   np.pi * r_pin**2)  +6*(28.9-   np.pi *0.39**2 )+28.9# Задаем объем единичной высоты. Нужно для моделирования выгорания
coolant.volume=(28.9-   np.pi * r_pin**2)*33
coolant.depletable = True
coolant.temperature = coolant_temperature

#--------------------------------------------------------------------------------
#Lower structure
# нижняя часть циркониевый сплав не нужно
structure = openmc.Material( name='Structure')
structure.add_nuclide('Na23',1.55910002E-02)

structure.add_nuclide('Fe54', 9.280691E-04)
structure.add_nuclide('Fe56', 1.45687E-02)
structure.add_nuclide('Fe57', 3.364548E-04)
structure.add_nuclide('Fe58', 4.477596E-05)

structure.add_nuclide('Ni58', 2.219582E-03)
structure.add_nuclide('Ni60', 8.549747E-04)
structure.add_nuclide('Ni61', 3.716856E-05)
structure.add_nuclide('Ni62', 1.184829E-04)
structure.add_nuclide('Ni64', 3.01913E-05)

structure.add_nuclide('Cr50', 4.504027E-04)
structure.add_nuclide('Cr52', 8.685568E-03)
structure.add_nuclide('Cr53', 9.848736E-04)
structure.add_nuclide('Cr54', 2.451559E-04)

structure.add_nuclide('Mn55', 5.0846E-04)

structure.add_nuclide('Mo92', 6.458961E-05)
structure.add_nuclide('Mo94', 6.458961E-05)
structure.add_nuclide('Mo95', 6.929021E-05)
structure.add_nuclide('Mo96', 6.929021E-05)
structure.add_nuclide('Mo97', 4.156542E-05)
structure.add_nuclide('Mo98', 1.050234E-04)
structure.add_nuclide('Mo100', 4.191361E-05)

structure.temperature=structure_temperature

#--------------------------------------------------------------------------------
#

# Материальный состав сплава Э-110, плотность 6,55 г/см clad for fuel
clading = openmc.Material( name='Clad')
clading.add_element('Zr', 4.259E-02)
clading.add_element('Nb', 4.225E-04)
clading.add_element('Hf', 6.597E-06)
clading.temperature = fuel_temperature

#материалы для стержня с выгарающим поглотителем
svp= openmc.Material( name="absorber")
svp.add_element('Gd', 1.9937e-2)
svp.add_element('O', 2.9906e-2)
#svp.volume =(12+0.32*6)* (np.pi * r_svp**2)
svp.volume=np.pi * r_pin ** 2*33
svp.temperature = fuel_temperature
svp.depletable = True

svpmin= openmc.Material( name="absorber")
svpmin.add_element('Gd', 1.9937e-2)
svpmin.add_element('O', 2.9906e-2)
#svp.volume =(12+0.32*6)* (np.pi * r_svp**2)
svpmin.volume=np.pi * (0.39/2) ** 2*33
svpmin.temperature = fuel_temperature
svpmin.depletable = True

# Сердечник стержня АЗ = Карбид бора 90%
conc = 2.5*6.023e23/52
protection = openmc.Material( name="protection_AZ")
protection.add_nuclide('B10',0.9*4*conc*1e-24)
protection.add_nuclide('B11',0.1*4*conc*1e-24)
protection.add_nuclide('C12',conc*1e-24)

# Гильза для стержня АЗ = Сплав Э-125
gilza = openmc.Material( name = 'gilza-AZ')
gilza.add_element('Zr',4.182e-02)
gilza.add_element('Nb',1.071e-03)
gilza.remove_nuclide('Zr96')




