import os
import openmc
import sys
#sys.path.append('../')

import numpy as np
import math
from chanel_3d import get_plane, set_chanel_3d
from matplotlib import pyplot as plt
from depletion_steps import depletion_steps
from materials import fuel_type1inner,  fuel_type1outer
from materials import fuel_type2inner,  fuel_type2outer
from materials import fuel_type3inner,  fuel_type3outer
from materials import fuel_type4inner,  fuel_type4outer
from materials import fuel_type5inner,  fuel_type5outer
from materials import coolant,  clading,svp,protection,gilza,svpmin

from control_rods_up_calculation import fa_3d_rod
from fa_calculation_true import fa_3d
from coolant import coolant_3d

chain_file = "/home/adminsrv/projects/sections/endfb-viii.0-hdf5/chain_casl_pwr.xml"
os.environ["OPENMC_CROSS_SECTIONS"] = "/home/adminsrv/projects/sections/endfb-viii.0-hdf5/cross_sections.xml"
openmc.config['cross_sections'] = "/home/adminsrv/projects/sections/endfb-viii.0-hdf5/cross_sections.xml"

mats = openmc.Materials((fuel_type1inner, 
                         fuel_type2inner,
                         fuel_type3inner,
                         fuel_type4inner,
                         fuel_type5inner,
                         fuel_type1outer,
                         fuel_type2outer,
                         fuel_type3outer,
                         fuel_type4outer,
                         fuel_type5outer,
                         clading, coolant,svp,protection,gilza,svpmin))
                         
mats.export_to_xml()





#---------------------------------------------
# размер под ключ для ТВС
# создаем окружающие ТВС
outer_coolant_cell = openmc.Cell(fill=coolant)
outer_universe = openmc.Universe(cells=(outer_coolant_cell,))
HH=9.85
lattice = openmc.HexLattice( lattice_id=100, name='core_lattice')
lattice.center = (0., 0.)
lattice.pitch = (HH,)
#lattice.orientation = 'x'
lattice.outer = outer_universe




#print(lattice.show_indices(num_rings=12))


fuels_inner_lst  = [fuel_type1inner,fuel_type2inner,fuel_type3inner,fuel_type4inner,fuel_type5inner]
fuels_outer_lst  = [fuel_type1outer,fuel_type2outer,fuel_type3outer,fuel_type4outer,fuel_type5outer]


#is_void=False
control_rods_univ     = fa_3d_rod(tvs_ind=1000, boundary="transmission" ) 
fa_inner_univ         = fa_3d(tvs_ind=2000, fuels_lst=fuels_inner_lst, boundary="transmission") 
fa_outer_univ         = fa_3d(tvs_ind=4000, fuels_lst=fuels_outer_lst, boundary="transmission")

coolant_univ          = coolant_3d( coolant = coolant, boundary="transmission")

#------------------------------------------------------------------


# схема расположения
ring_1     =  [fa_outer_univ]*1#[control_rods_univ]*1
ring_2     =  [fa_outer_univ]*6
ring_3     =  [fa_outer_univ]*12
ring_4     =  ( [fa_outer_univ]  + [fa_outer_univ]*2 ) *6
ring_5     =  ([fa_outer_univ]*2+[control_rods_univ]+[fa_outer_univ])*6
ring_6     =  ( [fa_outer_univ ] + [fa_outer_univ]*4 ) *6
ring_7     =  ([fa_outer_univ ] + [fa_outer_univ]*2)*12
ring_8     =  ([control_rods_univ]*1 + [fa_outer_univ]*6 ) * 6
ring_9     =  ([fa_inner_univ ]*2 + [fa_inner_univ]*5 + [fa_inner_univ]*1) * 6
ring_10    =  ([fa_inner_univ]*4+[control_rods_univ]+[fa_inner_univ]*4)*6
ring_11    =  ([fa_inner_univ ]*2 + [fa_inner_univ ]*7 + [fa_inner_univ ]*1)*6
ring_12    =  ([coolant_univ]*3 + [fa_inner_univ ]*6 + [coolant_univ]*2)*6
#extra_13    =  [radial_shield_univ]*72





lattice.universes = [ring_12, ring_11, ring_10, ring_9, ring_8, ring_7, ring_6, ring_5, ring_4, ring_3, ring_2, ring_1]
lattice.orientation = 'x'

print(lattice)






z0 = 0               # cm core down position
#z1 = 35.76           # cm Lower structure
#z2 = z1 + 125.16     # cm Lower reflector
z3 = z0 + 165     # cm Radial reflector
#z_us = z3 + 112.39   # cm Upper structure
core_down = openmc.ZPlane(z0= z0+2 , boundary_type="vacuum")
core_up = openmc.ZPlane(z0= z3-2 , boundary_type="vacuum")




# размер под ключ для кластера
Hcluster=HH*12
cluster_border = get_plane(H= Hcluster, orientation="y", boundary="vacuum")

cluster_region = -cluster_border[1] & -cluster_border[2] & -cluster_border[3] & -cluster_border[4] & -cluster_border[5] & -cluster_border[6] & -core_up & +core_down

main_cell = openmc.Cell(fill=lattice, region= cluster_region)
geom = openmc.Geometry([main_cell])
geom.export_to_xml()







z_core_pos = 165/2

# печать картинки
p = openmc.Plot()
p.origin=(0,0,z_core_pos)
p.basis = "xz"
#p.filename = f'met_1000_core_z_up_is_void_{is_void}'
p.width = (HH*33, HH*33)
p.pixels = (5000, 5000)
p.color_by = 'material'

p.colors = {fuel_type1inner: 'red',
            fuel_type2inner: 'orange',
            fuel_type3inner: 'magenta',
            fuel_type4inner: 'coral',
            fuel_type5inner: 'pink',
            coolant: 'blue',
            clading:'gray',
            svp:'green',
            svpmin: 'green',
            protection : 'black',
            gilza :'yellow'           
            }            

plots = openmc.Plots([p])
plots.export_to_xml()
openmc.plot_geometry()

#------------------
# печать картинки
p = openmc.Plot()
p.origin=(0,0,100)
p.basis = "xy"
#p.filename = f'met_1000_core_xy_up_is_void_{is_void}'
p.width = (HH*33, HH*33)
p.pixels = (5000, 5000)
p.color_by = 'material'
p.colors = {fuel_type1inner: 'red',
            fuel_type2inner: 'orange',
            fuel_type3inner: 'magenta',
            fuel_type4inner: 'coral',
            fuel_type5inner: 'pink',
            coolant: 'blue',
            clading:'gray',
            svp :'green',
            svpmin: 'green',
            protection : 'black',
            gilza :'yellow'  
            }            



plots = openmc.Plots([p])
plots.export_to_xml()
openmc.plot_geometry()
#--------------




#Computing settings
batches = 100
inactive = 20
particles = 300



settings = openmc.Settings()
settings.batches = batches
settings.inactive = inactive
settings.particles = particles
settings.output = {'tallies': True}
settings.temperature = {'method': 'interpolation'}
box_size = HH*2
uniform_dist = openmc.stats.Box([-box_size,-box_size,100],[box_size,box_size,120],only_fissionable=True)
settings.source = openmc.source.Source(space=uniform_dist)
settings.export_to_xml()






# openmc.run()

settings=openmc.model.Model.from_xml(geometry='/home/adminsrv/projects/Viktor/RITM_WITH_1_CONTROL_ROD/core/geometry.xml', materials='/home/adminsrv/projects/Viktor/RITM_WITH_1_CONTROL_ROD/core/materials.xml', settings='/home/adminsrv/projects/Viktor/RITM_WITH_1_CONTROL_ROD/core/settings.xml')
op = openmc.deplete.Operator(settings, chain_file)
# gramms_hm = op.heavy_metal
#print(gramms_hm)
#

    #fuel_assembly_area = 26.9 #pi*d**2/4*ntvs#107.7/4 # cm2
n_tvs=349
htvs = 165
ntvel = 72
core_power=380*10**6
tvs_power=core_power/n_tvs
tvel_area=np.pi*0.69**2/4
qvtvs=tvs_power/htvs # мощность ТВС единичной высоты
qv=qvtvs/ntvel/tvel_area#=245.1

linear_power = core_power / n_tvs  / ntvel / htvs  # Вт/см^2


sec_in_day = 24 * 60 * 60
# depletion_steps1=np.array(depletion_steps)
timesteps_openmc = depletion_steps# * sec_in_day
    #timesteps_openmc = [float(100*(i+1))* sec_in_day for i in range(200)] #* sec_in_day
print(depletion_steps)
# time_step=[21.5096850830981*sec_in_day]*60

integrator = openmc.deplete.CELIIntegrator(operator=op, timesteps=timesteps_openmc, power = 245.1) #вт/см:3
integrator.integrate()



