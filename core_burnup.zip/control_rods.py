import os
import openmc
import numpy as np
import math

#from mc2py.openmc.chanel_3d import get_plane, set_chanel_3d
from chanel_3d import get_plane, set_chanel_3d
import sys

from materials import fuel_type1inner
from materials import fuel_type2inner
from materials import fuel_type3inner
from materials import fuel_type4inner
from materials import fuel_type5inner
from materials import coolant, structure, clading, svp,gilza, protection




def assembly_construct( id=100, cell_name="universe",fuel=fuel_type1inner, clading=clading, coolant=coolant, absorber= svp, gilza=gilza, absorber1 = protection, zx=None, zup=None, zdn=None, boundary="transmission/reflective"):
    #pin geome -  описываем топливную ячейку
    r_pin = openmc.ZCylinder(r=0.69/2) # cm
    r_clad= openmc.ZCylinder(r=0.69/2+0.03) # cm
    r_stergen=openmc.ZCylinder(r=1.1)
    r_gilza=openmc.ZCylinder(r=1.1+0.4)
    pin_to_pin_dist = 3  # cm
    edge_length = pin_to_pin_dist / np.sqrt(3)

    fuel_cell = openmc.Cell( fill=fuel, region=-r_pin & -zup & +zdn)
    clad_cell = openmc.Cell( fill=clading, region=+r_pin &-r_clad & -zup & +zdn)
    coolant_cell = openmc.Cell(fill=coolant, region=+r_clad &  -zup & +zdn)
    root_pins = openmc.Universe(cells=(fuel_cell, clad_cell, coolant_cell))
    
    
    stergen_cell = openmc.Cell( fill=coolant, region=-r_stergen & -zup & +zdn)
#    stergen_cell = openmc.Cell( fill=absorber1, region=-r_stergen & -zup & +zx)
#    coolant_in_gilxa_cell=openmc.Cell( fill=coolant, region=-r_stergen & -zx & +zdn)
    gilza_cell = openmc.Cell( fill=gilza, region=+r_stergen &-r_gilza & -zup & +zdn)
    coolant_for_gilza_cell = openmc.Cell(fill=coolant, region=+r_gilza &  -zup & +zdn)
    stergen_pins = openmc.Universe(cells=(stergen_cell, gilza_cell, coolant_for_gilza_cell))



#    if absorber_insert:
#        absorber_cell = openmc.Cell( fill=absorber, region=-r_pin & -zup & +zdn)
#        clad1_cell = openmc.Cell( fill=clading, region=+r_pin &-r_clad & -zup & +zdn)
#        coolant1_cell = openmc.Cell(fill=coolant, region=+r_clad &  -zup & +zdn)
#        absorber_pins = openmc.Universe(cells=(absorber_cell, clad1_cell, coolant1_cell))
#    else:
#     coolant1_cell = openmc.Cell(fill=coolant, region=-r_stergen &  -zx & +zdn)
#     coolant2_cell = openmc.Cell(fill=coolant, region=+r_gilza &  -zup & +zdn)
#     gilza1_cell = openmc.Cell( fill=gilza, region=+r_stergen &-r_gilza & -zup & +zdn)
#     absorber_pins = openmc.Universe(cells=(coolant1_cell, coolant2_cell,gilza1_cell))





    # Create assembly - описываем топливную сборку в гексагональной геометрии
    assembly = openmc.HexLattice(  name='Fuel Assembly {}'.format(cell_name) )
    assembly.pitch = [pin_to_pin_dist]
    assembly.center = (0.0, 0.0)
#    num_elements_assembly = [[1, 30],[2, 24], [3, 18], [4, 12], [5, 6], [6, 1] ] # Number elements on ring ryadi
    #universes = [[root_pins]*num_in_ring[1] for num_in_ring in num_elements_assembly]


    r2=[root_pins]*6
    r1=[stergen_pins]*1
    universes = [r2,r1]
    assembly.universes = universes

    


    # заполняем теплоноситель, между чехлом и решеткой ТВС
    coolant_between_lattice_and_chanel = openmc.Universe()
    collant_tvs = openmc.Cell(name="Coolant between lattice and chanel", fill=coolant)
    coolant_between_lattice_and_chanel.add_cell(collant_tvs)
    assembly.outer = coolant_between_lattice_and_chanel # coolant_universe


    # устанавливаем чехол
    subassembly_duct = 10 # cm  Subassembly duct outer flat-to-flat distance
    H = subassembly_duct
    R = H / math.sqrt(3)
    p1 = openmc.Plane(a=1/H, b=1/R, c=0, d=0)
    p2 = openmc.XPlane(x0=0)
    p3 = openmc.Plane(a=-1/H, b=1/R, c=0, d=0)

    # Create assembly clad  - оцениваем толщину чехла для ТВС
    thickness = 0.165 # cm Subassembly duct wall thickness
    bord_duct_inner = get_plane(H=H - 2*thickness, boundary="transmission")
    bord_duct_outer = get_plane(H= H, boundary="transmission")
    # создаем ячейки, которые будут описывать чехол
    duct_cells = set_chanel_3d(bord_outer=bord_duct_outer, bord_inner=bord_duct_inner, p1=p1,p2=p2,p3=p3, z_up=zup, z_down=zdn, material=clading, name="chanel")

    # создаем внешний слой теплоносителя
    H_fuel_assembly = 10.2 # cm Subassembly pitch
    bord_inner = get_plane(H=H, boundary="transmission")
    bord_outer = get_plane(H= H_fuel_assembly, boundary=boundary)
    # создаем ячейки, которые будут описывать чехол
    outer_coolant_cells = set_chanel_3d(bord_outer=bord_outer, bord_inner=bord_inner, p1=p1,p2=p2,p3=p3, z_up=zup, z_down=zdn, material=coolant, name="outer coolant")

    # создаем ТВС (без чехла), чтобы для нее можно было задать внешние границы
    assembly_inner_cell = openmc.Cell(name='assembly_inner_cell {}'.format(cell_name), fill=assembly)
    assembly_inner_cell.region = -bord_duct_inner[1] & -bord_duct_inner[2] & -bord_duct_inner[3] & -bord_duct_inner[4] & -bord_duct_inner[5] & -bord_duct_inner[6]  & -zup & +zdn

    # создадим universe, в которой обобщены все данные по конструкции ТВС в данном слое
    fuel_assembly_universe = openmc.Universe(name="fuel_assembly_universe {}".format(cell_name) )
    # добавим топливные ячейки
    fuel_assembly_universe.add_cell(assembly_inner_cell)
    # добавим чехол
    for one_cell in duct_cells.values():
        fuel_assembly_universe.add_cell(one_cell)
    # добавим внешний слой теплоносителя
    for one_cell in outer_coolant_cells.values():
        fuel_assembly_universe.add_cell(one_cell)

    # Create root Cell - создаем корневой объект, который и будет рассчитан по OpenMC
    root_cell = openmc.Cell(name= cell_name, fill=fuel_assembly_universe)
    root_cell.region = -bord_outer[1]  & -bord_outer[2] & -bord_outer[3]  & -bord_outer[4]  & -bord_outer[5]  & -bord_outer[6] & -zup & +zdn

    return root_cell



